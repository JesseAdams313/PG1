﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FSPG1
{
    class Program
    {
        static void Main(string[] args)
        {
            Test.Run();
            Console.ReadKey();
        }
    }
}
